'''
Created on 26 mar. 2019
Práctica 4.
Ejercicio 3.- Programa que lee notas de alumnos. Dejará de pedir notas al pulsar ENTER. Al terminar, mostrará todas las notas de los alumnos
y un resumen de aprobados y suspensos incluyendo la nota media.
@author: joseluis
'''

print("Introduzca las notas, ENTER para terminar: ")
notas = list()
salir = False
i = 0

while not salir:    
    nota = input("Nota del alumno "+ str(i+1) + ": ")
    if nota == "":
        salir = True
    else:
        notas.append(float(nota))
        i += 1

print("Se han introducido las siguientes notas: ")
aprobados = 0
suspensos = 0
sumaNotas = 0.0

for j in range(len(notas)):    
    print("\t", "Alumno", j+1, ":", notas[j])
    if notas[j] >= 5.0:
        aprobados += 1
    else:
        suspensos += 1
    sumaNotas += notas[j]
    
print("Resumen:")
print("\t", "Número de alumnos: ", len(notas))
print("\t", "Aprobados:", aprobados)
print("\t", "Suspensos:", suspensos)
print("\t", "Nota media:", round(sumaNotas/len(notas),2))


        
    