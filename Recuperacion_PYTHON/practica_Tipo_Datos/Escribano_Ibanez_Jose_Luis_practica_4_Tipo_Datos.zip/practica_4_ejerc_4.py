'''
Created on 26 mar. 2019
Práctica 4.
Ejercicio 4.- Programa que pide nombres. Tras pedirlos, debe mostrarlos ordenados.
@author: joseluis
'''

listaNombres = list() 
print("Introduzca nombres. ENTER para terminar:")
salir = False

while not salir:
    nombre = input() 
    if nombre == "":
        salir = True
    else:       
        listaNombres.append(nombre) 
     
listaNombres.sort()
        
print("Los nombres son: ")
for nombre in listaNombres:
    print(nombre)