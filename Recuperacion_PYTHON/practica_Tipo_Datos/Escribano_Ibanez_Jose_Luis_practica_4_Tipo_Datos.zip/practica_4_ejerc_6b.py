'''
Created on 26 mar. 2019
Práctica 4.
Ejercicio 6.- Programa que calcule los 100 primeros números de la sucesión de Fibonacci y los almacene en una lista y muestre por pantalla.
Versión 1 - Hecho con lista.
@author: joseluis
'''
from __future__ import print_function

listaFibo = list()

for i in range(0, 100):
    if i == 0:
        listaFibo.append(0)
    elif i == 1:
        listaFibo.append(1)
    else:
        listaFibo.append(listaFibo[i-1] + listaFibo[i-2])
        
for fibo in listaFibo:
    print(fibo, end = ', ')
